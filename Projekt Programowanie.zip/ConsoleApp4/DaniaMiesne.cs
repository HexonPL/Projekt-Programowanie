﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ConsoleApp4
{
    class DaniaMiesne : Produkt
    {
        public string OpisMiesne { get; set; }

        public DaniaMiesne(int Id,string Nazwa,int Cena,string OpisMiesne) :base(Id,Nazwa,Cena)
        {
            this.OpisMiesne = OpisMiesne;
        }

        public override void Przedstawienie()
        {
            base.Przedstawienie();
            Console.WriteLine("Pyszne soczyste mięso, które podajemy to 8 cud na Ziemi");
        }
    }
}

