﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    class Napoje : Produkt
    {
        public string OpisNapoje { get; set; }

        public Napoje(int Id, string Nazwa, int Cena, string OpisNapoje) : base(Id, Nazwa, Cena)
        {
            this.OpisNapoje = OpisNapoje;
        }

        public override void Przedstawienie()
        {
            base.Przedstawienie();
            Console.WriteLine("Tylko u nas takie przeceny na napoje w zestawach");
        }
    }
}
