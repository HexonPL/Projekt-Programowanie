﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    class Produkt
    {
        public int Id { get; set; }
        public string Nazwa { get; set; }
        public float Cena { get; set; }

        public Produkt(int id, string nazwa, float cena)
        {
            this.Id = id;
            this.Nazwa = nazwa;
            this.Cena = cena;
        }

        public virtual void Przedstawienie()
        {
            Console.WriteLine(" ");
        }
    }
}
