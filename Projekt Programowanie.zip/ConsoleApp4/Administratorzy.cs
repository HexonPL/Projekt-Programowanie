﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;

namespace ConsoleApp4
{
    class Administratorzy
    {
        public string LoginAdmin { get; set; }
        public string HasloAdmin { get; set; }

        public Administratorzy(string loginadmin, string hasloadmin)
        {
            this.LoginAdmin = loginadmin;
            this.HasloAdmin = hasloadmin;
        }

        public static void LoginAdmi()
        {
            //////////////////////////////////////////////
            string fileName = "administratorzy.txt";
            List<Administratorzy> admin = new List<Administratorzy>();
            String line;
            StreamReader sr4 = new StreamReader(fileName);
            while ((line = sr4.ReadLine()) != null)
            {
                string[] s = line.Split(',');
                string g = s[0];
                string i = s[1];
                admin.Add(new Administratorzy(g, i));
            }
            sr4.Close();
        ////////////////////////////////////////////////
        Login:
            Console.Clear();
            Console.WriteLine("1. Wpisz Login");
            string b = Console.ReadLine();
            int number;
            bool success = Int32.TryParse(b, out number);
            if (success)
            {
                Console.Clear();
                Console.WriteLine("Prosze o wpisywanie liter");
                goto Login;
            }
            else
            {
                bool bExist3 = admin.Exists(Element1 => Element1.LoginAdmin.Equals(b));
                if (bExist3 == true)
                {
                Haslo:
                    Console.Clear();
                    Console.WriteLine("2. Wpisz Hasło");
                    string b2 = Console.ReadLine();
                    int number2;
                    bool success2 = Int32.TryParse(b2, out number2);
                    if (success2)
                    {
                        Console.Clear();
                        Console.WriteLine("Prosze o wpisywanie liter");
                        goto Haslo;
                    }
                    else
                    {
                        bool bExist33 = admin.Exists(Element1 => Element1.HasloAdmin.Equals(b2));

                        if (bExist33 == true)
                        {
                            Console.Clear();
                            Console.WriteLine("Zalogowano Pomyślnie");
                            System.Threading.Thread.Sleep(2200);
                            Console.Clear();
                            Menu.PokazMenu();
                        }
                        else
                        {
                            Console.Clear();
                            Console.WriteLine("Taki uzytkownik nie istnieje");
                            System.Threading.Thread.Sleep(2200);
                            Console.Clear();
                            goto Haslo;
                        }
                    }

                }
                else
                {
                    Console.Clear();
                    Console.WriteLine("Taki uzytkownik nie istnieje");
                    System.Threading.Thread.Sleep(2200);
                    Console.Clear();
                    goto Login;
                }
            }

        }
    }
}