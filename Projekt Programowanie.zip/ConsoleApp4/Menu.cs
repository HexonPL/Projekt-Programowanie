﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;

namespace ConsoleApp4
{
    class Menu
    {
        public static void PokazMenu()
        {
            //////////////////////////////////////////////
            string fileName = "dania_miesne.txt";
            List<DaniaMiesne> dania = new List<DaniaMiesne>();
            String line;
            StreamReader sr = new StreamReader(fileName);
            while ((line = sr.ReadLine()) != null)
            {
                string[] s = line.Split(',');

                int f = int.Parse(s[0]);
                string g = s[1];
                int h = int.Parse(s[2]);
                string i = s[3];
                dania.Add(new DaniaMiesne(f,g,h,i));
            }
            sr.Close();
            ////////////////////////////////////////////////
            string fileName1 = "dania_rybne.txt";
            List<DaniaRybne> dania1 = new List<DaniaRybne>();
            String line1;
            StreamReader sr1 = new StreamReader(fileName1);
            while ((line1 = sr1.ReadLine()) != null)
            {
                string[] s1 = line1.Split(',');
                int f1 = int.Parse(s1[0]);
                string g1 = s1[1];
                int h1 = int.Parse(s1[2]);
                string i1 = s1[3];
                dania1.Add(new DaniaRybne(f1, g1, h1, i1));
            }
            sr1.Close();
            ////////////////////////////////////////////////
            string fileName2 = "desery.txt";
            List<Desery> dania2 = new List<Desery>();
            String line2;
            StreamReader sr2 = new StreamReader(fileName2);
            while ((line2 = sr2.ReadLine()) != null)
            {
                string[] s2 = line2.Split(',');
                int f2 = int.Parse(s2[0]);
                string g2 = s2[1];
                int h2 = int.Parse(s2[2]);
                string i2 = s2[3];
                dania2.Add(new Desery(f2, g2, h2, i2));
            }
            sr2.Close();
            ////////////////////////////////////////////////
            string fileName3 = "napoje.txt";
            List<Napoje> dania3 = new List<Napoje>();
            String line3;
            StreamReader sr3 = new StreamReader(fileName3);
            while ((line3 = sr3.ReadLine()) != null)
            {
                string[] s3 = line3.Split(',');
                int f3 = int.Parse(s3[0]);
                string g3 = s3[1];
                int h3 = int.Parse(s3[2]);
                string i3 = s3[3];
                dania3.Add(new Napoje(f3, g3, h3, i3));
            }
            sr3.Close();
            ////////////////////////////////////////////////
            string fileName4 = "pierogi.txt";
            List<Pierogi> dania4 = new List<Pierogi>();
            String line4;
            StreamReader sr4 = new StreamReader(fileName4);
            while ((line4 = sr4.ReadLine()) != null)
            {
                string[] s4 = line4.Split(',');
                int f4 = int.Parse(s4[0]);
                string g4 = s4[1];
                int h4 = int.Parse(s4[2]);
                string i4 = s4[3];
                dania4.Add(new Pierogi(f4, g4, h4, i4));
            }
            sr4.Close();
            ////////////////////////////////////////////////
            string fileName5 = "salaty.txt";
            List<Salaty> dania5 = new List<Salaty>();
            String line5;
            StreamReader sr5 = new StreamReader(fileName5);
            while ((line5 = sr5.ReadLine()) != null)
            {
                string[] s5 = line5.Split(',');
                int f5 = int.Parse(s5[0]);
                string g5 = s5[1];
                int h5 = int.Parse(s5[2]);
                string i5 = s5[3];
                dania5.Add(new Salaty(f5, g5, h5, i5));
            }
            sr5.Close();
            ////////////////////////////////////////////////
            string fileName6 = "zupy.txt";
            List<Zupy> dania6 = new List<Zupy>();
            String line6;
            StreamReader sr6 = new StreamReader(fileName6);
            while ((line6 = sr6.ReadLine()) != null)
            {
                string[] s6 = line6.Split(',');
                int f6 = int.Parse(s6[0]);
                string g6 = s6[1];
                int h6 = int.Parse(s6[2]);
                string i6 = s6[3];
                dania6.Add(new Zupy(f6, g6, h6, i6));
            }
            sr6.Close();
        ////////////////////////////////////////////////




            Console.WriteLine("===============================================");
            Console.WriteLine("   Aplikacja zarządzająca menu restauracji");
            Console.WriteLine("===============================================");
            Console.WriteLine(" ");
            System.Threading.Thread.Sleep(2500);
            Console.WriteLine("=====================================================");
            Console.WriteLine(" Autorzy : Krzysztof Szałamacha , Oskar Suliński  K29");
            Console.WriteLine("=====================================================");
            Console.WriteLine(" ");
            System.Threading.Thread.Sleep(3600);
            Console.Clear();
        Menu:
            Console.WriteLine("===========================");
            Console.WriteLine("    Wybierz Numer z Listy :");
            Console.WriteLine("===========================");
            Console.WriteLine(" ");
            Console.WriteLine("1. Dania Miesne ");
            Console.WriteLine("2. Dania Rybne ");
            Console.WriteLine("3. Napoje ");
            Console.WriteLine("4. Desery ");
            Console.WriteLine("5. Zupy ");
            Console.WriteLine("6. Pierogi ");
            Console.WriteLine("7. Sałaty ");
            Console.WriteLine("==================");
            Console.WriteLine("8. Zamknij program ");
            Console.WriteLine("==================");
            switch (Console.ReadLine())
            {
                case "1":
                    Console.Clear();
                    foreach (DaniaMiesne danie in dania)
                    {
                        Console.WriteLine(" ");
                        Console.WriteLine("=================================");
                        Console.WriteLine($"Numer na Liście: {danie.Id}");
                        Console.WriteLine($"Nazwa: {danie.Nazwa}");
                        Console.WriteLine($"Cena: {danie.Cena}");
                        Console.WriteLine($"Opis: {danie.OpisMiesne}");
                        Console.WriteLine("=================================");
                    }
                    Console.WriteLine(" ");
                    Console.WriteLine(" ");
                    Console.WriteLine(" ");
                    Console.WriteLine("1. Dodaj przedmiot");
                    Console.WriteLine("2. Usuń przedmiot");
                    Console.WriteLine("3. Powrót do menu");
                    string a = Console.ReadLine();
                    if(a=="3")
                    {
                        Console.Clear();
                        goto Menu;
                    }
                    else
                    {

                    }
                    if(a=="1")
                    {

                        Console.Clear();
                        Console.WriteLine(" ");
                        Console.WriteLine("========================== ");
                        Console.WriteLine("    DODAWANIE DO MENU ");
                        Console.WriteLine("========================== ");
                        Console.WriteLine(" ");
                        foreach (DaniaMiesne danie in dania)
                        {
                            Console.WriteLine(" ");
                            Console.WriteLine("=================================");
                            Console.WriteLine($"Numer na Liście: {danie.Id}");
                            Console.WriteLine($"Nazwa: {danie.Nazwa}");
                            Console.WriteLine($"Cena: {danie.Cena}");
                            Console.WriteLine($"Opis: {danie.OpisMiesne}");
                            Console.WriteLine("=================================");
                        }
                        Console.WriteLine(" ");
                        Console.WriteLine(" ");
                    Wroc:
                        Console.WriteLine("1. Podaj kolejne wolne Id");
                        string b = Console.ReadLine();
                        int number;
                        bool success = Int32.TryParse(b, out number);
                        if (success)
                        {
                            Console.Clear();
                            bool bExist3 = dania.Exists(Element3 => Element3.Id.Equals(number));
                            if (bExist3)
                            {
                                Console.Clear();
                                Console.WriteLine("Podane Id już istnieje");
                                System.Threading.Thread.Sleep(2200);
                                Console.Clear();
                                Console.WriteLine(" ");
                                foreach (DaniaMiesne danie in dania)
                                {
                                    Console.WriteLine(" ");
                                    Console.WriteLine("=================================");
                                    Console.WriteLine($"Numer na Liście: {danie.Id}");
                                    Console.WriteLine($"Nazwa: {danie.Nazwa}");
                                    Console.WriteLine($"Cena: {danie.Cena}");
                                    Console.WriteLine($"Opis: {danie.OpisMiesne}");
                                    Console.WriteLine("=================================");
                                }
                                Console.WriteLine(" ");
                                goto Wroc;
                            }
                            else
                            {

                            }

                        }
                        else
                        {
                            Console.Clear();
                            Console.WriteLine("Proszę wpisać liczbę !");
                            System.Threading.Thread.Sleep(2200);
                            Console.Clear();
                            Console.WriteLine(" ");
                            foreach (DaniaMiesne danie in dania)
                            {
                                Console.WriteLine(" ");
                                Console.WriteLine("=================================");
                                Console.WriteLine($"Numer na Liście: {danie.Id}");
                                Console.WriteLine($"Nazwa: {danie.Nazwa}");
                                Console.WriteLine($"Cena: {danie.Cena}");
                                Console.WriteLine($"Opis: {danie.OpisMiesne}");
                                Console.WriteLine("=================================");
                            }
                            Console.WriteLine(" ");
                            goto Wroc;
                        }

                        Wroc1:
                        Console.WriteLine("2. Podaj Nazwe");
                        string c = Console.ReadLine();
                        int number1;
                        bool success1 = Int32.TryParse(c, out number1);
                        if (success1)
                        {
                            Console.Clear();
                            Console.WriteLine("Proszę wpisać znaki nie liczby !");
                            System.Threading.Thread.Sleep(2200);
                            Console.Clear();
                            Console.WriteLine(" ");
                            foreach (DaniaMiesne danie in dania)
                            {
                                Console.WriteLine(" ");
                                Console.WriteLine("=================================");
                                Console.WriteLine($"Numer na Liście: {danie.Id}");
                                Console.WriteLine($"Nazwa: {danie.Nazwa}");
                                Console.WriteLine($"Cena: {danie.Cena}");
                                Console.WriteLine($"Opis: {danie.OpisMiesne}");
                                Console.WriteLine("=================================");
                            }
                            Console.WriteLine(" ");
                            goto Wroc1;
                        }
                        else
                        {
                            Console.Clear();
                        }
                        Wroc2:
                        Console.WriteLine("3. Podaj cene bez przecinków i kropek");
                        string d = Console.ReadLine();
                        int number2;
                        bool success2 = Int32.TryParse(d, out number2);
                        if (success2)
                        {
                            Console.Clear();
                        }
                        else
                        {
                            Console.Clear();
                            Console.WriteLine("Cena to liczba nie znaki !");
                            System.Threading.Thread.Sleep(2200);
                            Console.Clear();
                            Console.WriteLine(" ");
                            foreach (DaniaMiesne danie in dania)
                            {
                                Console.WriteLine(" ");
                                Console.WriteLine("=================================");
                                Console.WriteLine($"Numer na Liście: {danie.Id}");
                                Console.WriteLine($"Nazwa: {danie.Nazwa}");
                                Console.WriteLine($"Cena: {danie.Cena}");
                                Console.WriteLine($"Opis: {danie.OpisMiesne}");
                                Console.WriteLine("=================================");
                            }
                            Console.WriteLine(" ");
                            goto Wroc2;
                        }

                        Wroc3:
                        Console.WriteLine("4. Krótki opis");
                        string e = Console.ReadLine();
                        int number3;
                        bool success3 = Int32.TryParse(e, out number3);
                        if (success3)
                        {
                            Console.Clear();
                            Console.WriteLine("Opis sklada sie w tym wypadku tylko ze znakow !");
                            System.Threading.Thread.Sleep(2200);
                            Console.Clear();
                            Console.WriteLine(" ");
                            foreach (DaniaMiesne danie in dania)
                            {
                                Console.WriteLine(" ");
                                Console.WriteLine("=================================");
                                Console.WriteLine($"Numer na Liście: {danie.Id}");
                                Console.WriteLine($"Nazwa: {danie.Nazwa}");
                                Console.WriteLine($"Cena: {danie.Cena}");
                                Console.WriteLine($"Opis: {danie.OpisMiesne}");
                                Console.WriteLine("=================================");
                            }
                            Console.WriteLine(" ");
                            goto Wroc3;
                        }
                        else
                        {
                            Console.Clear();
                        }
                        dania.Add(new DaniaMiesne(number,c,number2,e));
                        Console.WriteLine(" ");
                        Console.Clear();
                        foreach (DaniaMiesne danie in dania)
                        {
                            Console.WriteLine(" ");
                            Console.WriteLine("=================================");
                            Console.WriteLine($"Numer na Liście: {danie.Id}");
                            Console.WriteLine($"Nazwa: {danie.Nazwa}");
                            Console.WriteLine($"Cena: {danie.Cena}");
                            Console.WriteLine($"Opis: {danie.OpisMiesne}");
                            Console.WriteLine("=================================");
                        }

                        using (StreamWriter sw = new StreamWriter("dania_miesne.txt"))
                        {
                            foreach (DaniaMiesne danie in dania)
                            {
                                sw.WriteLine("{0},{1},{2},{3}",(danie.Id),danie.Nazwa,danie.Cena,danie.OpisMiesne);

                            }
                            sw.Close();
                        }

                        Console.WriteLine(" ");
                        Console.WriteLine("Co chcesz zrobić? ");
                        Console.WriteLine(" ");
                        Console.WriteLine("1. Powrót do głównego MENU");
                        int powrot_daniamiesne = int.Parse(Console.ReadLine());
                        if (powrot_daniamiesne == 1)
                        {
                            Console.Clear();
                            goto Menu;
                        }
                        else
                        {
                        }
                    }
                    else
                    {
                        Console.Clear();
                        Console.WriteLine("==================");
                        Console.WriteLine("   USUWANIE");
                        Console.WriteLine("==================");
                        Console.WriteLine(" ");
                        Console.WriteLine(" ");
                        foreach (DaniaMiesne danie in dania)
                        {
                            Console.WriteLine(" ");
                            Console.WriteLine("=================================");
                            Console.WriteLine($"Numer na Liście: {danie.Id}");
                            Console.WriteLine($"Nazwa: {danie.Nazwa}");
                            Console.WriteLine($"Cena: {danie.Cena}");
                            Console.WriteLine($"Opis: {danie.OpisMiesne}");
                            Console.WriteLine("=================================");
                        }
                        Console.WriteLine(" ");
                        Console.WriteLine(" ");
                        Console.WriteLine(" ");
                        Console.WriteLine(" ");
                        Console.WriteLine(" ");


                    Usuwanie:
                        Console.WriteLine("Podaj numer ID");
                        Console.WriteLine("====================================================================");
                        Console.WriteLine("   Pamiętaj !!! Numery w liscie zaczynają sie od 0 ");
                        Console.WriteLine("   Jeśli coś ma ID np 3 to 3-1 = 2 czyli trzeba usunąć nr 2  :)");
                        Console.WriteLine(" ");
                        Console.WriteLine("====================================================================");
                        Console.WriteLine("   Jeśli chcesz cofnąć do menu wciśnij     k :)");
                        Console.WriteLine("====================================================================");
                        string usuwanie = Console.ReadLine();
                        int usuwanie1;
                        bool success20 = Int32.TryParse(usuwanie, out usuwanie1);
                        if (success20)
                        {
                            Console.Clear();
                            dania.RemoveAt(usuwanie1);

                            using (StreamWriter sw8 = new StreamWriter("dania_miesne.txt"))
                            {
                                foreach (DaniaMiesne danie in dania)
                                {
                                    sw8.WriteLine("{0},{1},{2},{3}", (danie.Id), danie.Nazwa, danie.Cena, danie.OpisMiesne);

                                }
                                sw8.Close();
                            }

                            goto Menu;
                        }
                        else
                        {
                            if (usuwanie == "k")
                            {
                                Console.Clear();
                                goto Menu;
                            }
                            else
                            {
                                Console.Clear();
                                Console.WriteLine("Podaj liczbe nie znak !");
                                System.Threading.Thread.Sleep(2200);
                                Console.Clear();
                                Console.WriteLine(" ");
                                foreach (DaniaMiesne danie in dania)
                                {
                                    Console.WriteLine(" ");
                                    Console.WriteLine("=================================");
                                    Console.WriteLine($"Numer na Liście: {danie.Id}");
                                    Console.WriteLine($"Nazwa: {danie.Nazwa}");
                                    Console.WriteLine($"Cena: {danie.Cena}");
                                    Console.WriteLine($"Opis: {danie.OpisMiesne}");
                                    Console.WriteLine("=================================");
                                }
                                Console.WriteLine(" ");
                                goto Usuwanie;
                            }
                        }



                    }
                    Console.WriteLine(" ");
                    break;
                //////////////////////////////////////////////
                case "2":
                    Console.Clear();
                    foreach (DaniaRybne danie1 in dania1)
                    {
                        Console.WriteLine(" ");
                        Console.WriteLine("=================================");
                        Console.WriteLine($"Numer na Liście: {danie1.Id}");
                        Console.WriteLine($"Nazwa: {danie1.Nazwa}");
                        Console.WriteLine($"Cena: {danie1.Cena}");
                        Console.WriteLine($"Opis: {danie1.OpisRybne}");
                        Console.WriteLine("=================================");
                    }
                    Console.WriteLine(" ");
                    Console.WriteLine("1. Dodaj przedmiot");
                    Console.WriteLine("2. Usuń przedmiot");
                    Console.WriteLine("3. Powrót do menu");
                    string a1 = Console.ReadLine();
                    if (a1 == "3")
                    {
                        Console.Clear();
                        goto Menu;
                    }
                    else
                    {

                    }
                    if (a1 == "1")
                    {

                        Console.Clear();
                        Console.WriteLine(" ");
                        Console.WriteLine("========================== ");
                        Console.WriteLine("    DODAWANIE DO MENU ");
                        Console.WriteLine("========================== ");
                        Console.WriteLine(" ");
                        foreach (DaniaRybne danie1 in dania1)
                        {
                            Console.WriteLine(" ");
                            Console.WriteLine("=================================");
                            Console.WriteLine($"Numer na Liście: {danie1.Id}");
                            Console.WriteLine($"Nazwa: {danie1.Nazwa}");
                            Console.WriteLine($"Cena: {danie1.Cena}");
                            Console.WriteLine($"Opis: {danie1.OpisRybne}");
                            Console.WriteLine("=================================");
                        }
                        Console.WriteLine(" ");
                    Wroc4:
                        Console.WriteLine("1. Podaj kolejne wolne Id");
                        string b4 = Console.ReadLine();
                        int number3;
                        bool success4 = Int32.TryParse(b4, out number3);
                        if (success4)
                        {
                            Console.Clear();
                            bool bExist2 = dania1.Exists(Element1 => Element1.Id.Equals(number3));
                            if (bExist2)
                            {
                                Console.Clear();
                                Console.WriteLine("Podane Id już istnieje");
                                System.Threading.Thread.Sleep(2200);
                                Console.Clear();
                                Console.WriteLine(" ");
                                foreach (DaniaRybne danie1 in dania1)
                                {
                                    Console.WriteLine(" ");
                                    Console.WriteLine("=================================");
                                    Console.WriteLine($"Numer na Liście: {danie1.Id}");
                                    Console.WriteLine($"Nazwa: {danie1.Nazwa}");
                                    Console.WriteLine($"Cena: {danie1.Cena}");
                                    Console.WriteLine($"Opis: {danie1.OpisRybne}");
                                    Console.WriteLine("=================================");
                                }
                                Console.WriteLine(" ");
                                goto Wroc4;
                            }
                            else
                            {

                            }
                        }
                        else
                        {
                            Console.Clear();
                            Console.WriteLine("Proszę wpisać liczbę !");
                            System.Threading.Thread.Sleep(2200);
                            Console.Clear();
                            Console.WriteLine(" ");
                            foreach (DaniaRybne danie1 in dania1)
                            {
                                Console.WriteLine(" ");
                                Console.WriteLine("=================================");
                                Console.WriteLine($"Numer na Liście: {danie1.Id}");
                                Console.WriteLine($"Nazwa: {danie1.Nazwa}");
                                Console.WriteLine($"Cena: {danie1.Cena}");
                                Console.WriteLine($"Opis: {danie1.OpisRybne}");
                                Console.WriteLine("=================================");
                            }
                            Console.WriteLine(" ");
                            goto Wroc4;
                        }

                    Wroc5:
                        Console.WriteLine("2. Podaj Nazwe");
                        string c3 = Console.ReadLine();
                        int number4;
                        bool success5 = Int32.TryParse(c3, out number4);
                        if (success5)
                        {
                            Console.Clear();
                            Console.WriteLine("Proszę wpisać znaki nie liczby !");
                            System.Threading.Thread.Sleep(2200);
                            Console.Clear();
                            Console.WriteLine(" ");
                            foreach (DaniaRybne danie1 in dania1)
                            {
                                Console.WriteLine(" ");
                                Console.WriteLine("=================================");
                                Console.WriteLine($"Numer na Liście: {danie1.Id}");
                                Console.WriteLine($"Nazwa: {danie1.Nazwa}");
                                Console.WriteLine($"Cena: {danie1.Cena}");
                                Console.WriteLine($"Opis: {danie1.OpisRybne}");
                                Console.WriteLine("=================================");
                            }
                            Console.WriteLine(" ");
                            goto Wroc5;
                        }
                        else
                        {
                            Console.Clear();
                        }
                    Wroc6:
                        Console.WriteLine("3. Podaj cene bez przecinków i kropek");
                        string d5 = Console.ReadLine();
                        int number6;
                        bool success6 = Int32.TryParse(d5, out number6);
                        if (success6)
                        {
                            Console.Clear();
                        }
                        else
                        {
                            Console.Clear();
                            Console.WriteLine("Cena to liczba nie znaki !");
                            System.Threading.Thread.Sleep(2200);
                            Console.Clear();
                            Console.WriteLine(" ");
                            foreach (DaniaRybne danie1 in dania1)
                            {
                                Console.WriteLine(" ");
                                Console.WriteLine("=================================");
                                Console.WriteLine($"Numer na Liście: {danie1.Id}");
                                Console.WriteLine($"Nazwa: {danie1.Nazwa}");
                                Console.WriteLine($"Cena: {danie1.Cena}");
                                Console.WriteLine($"Opis: {danie1.OpisRybne}");
                                Console.WriteLine("=================================");
                            }
                            Console.WriteLine(" ");
                            goto Wroc6;
                        }

                    Wroc7:
                        Console.WriteLine("4. Krótki opis");
                        string e7 = Console.ReadLine();
                        int number7;
                        bool success7 = Int32.TryParse(e7, out number7);
                        if (success7)
                        {
                            Console.Clear();
                            Console.WriteLine("Opis sklada sie w tym wypadku tylko ze znakow !");
                            System.Threading.Thread.Sleep(2200);
                            Console.Clear();
                            Console.WriteLine(" ");
                            foreach (DaniaRybne danie1 in dania1)
                            {
                                Console.WriteLine(" ");
                                Console.WriteLine("=================================");
                                Console.WriteLine($"Numer na Liście: {danie1.Id}");
                                Console.WriteLine($"Nazwa: {danie1.Nazwa}");
                                Console.WriteLine($"Cena: {danie1.Cena}");
                                Console.WriteLine($"Opis: {danie1.OpisRybne}");
                                Console.WriteLine("=================================");
                            }
                            Console.WriteLine(" ");
                            goto Wroc7;
                        }
                        else
                        {
                            Console.Clear();
                        }
                        dania1.Add(new DaniaRybne(number3, c3, number6, e7));
                        Console.WriteLine(" ");
                        Console.Clear();
                        foreach (DaniaRybne danie1 in dania1)
                        {
                            Console.WriteLine(" ");
                            Console.WriteLine("=================================");
                            Console.WriteLine($"Numer na Liście: {danie1.Id}");
                            Console.WriteLine($"Nazwa: {danie1.Nazwa}");
                            Console.WriteLine($"Cena: {danie1.Cena}");
                            Console.WriteLine($"Opis: {danie1.OpisRybne}");
                            Console.WriteLine("=================================");
                        }

                        using (StreamWriter sw1 = new StreamWriter("dania_rybne.txt"))
                        {
                            foreach (DaniaRybne danie1 in dania1)
                            {
                                sw1.WriteLine("{0},{1},{2},{3}", (danie1.Id), danie1.Nazwa, danie1.Cena, danie1.OpisRybne);

                            }
                            sw1.Close();
                        }

                        Console.WriteLine(" ");
                        Console.WriteLine("Co chcesz zrobić? ");
                        Console.WriteLine(" ");
                        Console.WriteLine("1. Powrót do głównego MENU");
                        int powrot_daniarybne = int.Parse(Console.ReadLine());
                        if (powrot_daniarybne == 1)
                        {
                            Console.Clear();
                            goto Menu;
                        }
                        else
                        {
                        }
                    }
                    else
                    {
                        Console.Clear();
                        Console.WriteLine("==================");
                        Console.WriteLine("   USUWANIE");
                        Console.WriteLine("==================");
                        Console.WriteLine(" ");
                        Console.WriteLine(" ");
                        foreach (DaniaRybne danie1 in dania1)
                        {
                            Console.WriteLine(" ");
                            Console.WriteLine("=================================");
                            Console.WriteLine($"Numer na Liście: {danie1.Id}");
                            Console.WriteLine($"Nazwa: {danie1.Nazwa}");
                            Console.WriteLine($"Cena: {danie1.Cena}");
                            Console.WriteLine($"Opis: {danie1.OpisRybne}");
                            Console.WriteLine("=================================");
                        }
                        Console.WriteLine(" ");


                    Usuwanie1:
                        Console.WriteLine("Podaj numer ID");
                        Console.WriteLine("====================================================================");
                        Console.WriteLine("   Pamiętaj !!! Numery w liscie zaczynają sie od 0 ");
                        Console.WriteLine("   Jeśli coś ma ID np 3 to 3-1 = 2 czyli trzeba usunąć nr 2  :)");
                        Console.WriteLine("====================================================================");
                        Console.WriteLine(" ");
                        Console.WriteLine("====================================================================");
                        Console.WriteLine("   Jeśli chcesz cofnąć do menu wciśnij     k :)");
                        Console.WriteLine("====================================================================");
                        string usuwanie2 = Console.ReadLine();
                        int usuwanie3;
                        bool success21 = Int32.TryParse(usuwanie2, out usuwanie3);
                        if (success21)
                        {
                            Console.Clear();
                            dania.RemoveAt(usuwanie3);

                            using (StreamWriter sw9 = new StreamWriter("dania_rybne.txt"))
                            {
                                foreach (DaniaRybne danie1 in dania1)
                                {
                                    sw9.WriteLine("{0},{1},{2},{3}", (danie1.Id), danie1.Nazwa, danie1.Cena, danie1.OpisRybne);

                                }
                                sw9.Close();
                            }
                            goto Menu;
                        }
                        else
                        {
                            if (usuwanie2 == "k")
                            {
                                Console.Clear();
                                goto Menu;
                            }
                            else
                            {
                                Console.Clear();
                                Console.WriteLine("Podaj liczbe nie znak !");
                                System.Threading.Thread.Sleep(2200);
                                Console.Clear();
                                Console.WriteLine(" ");
                                foreach (DaniaRybne danie1 in dania1)
                                {
                                    Console.WriteLine(" ");
                                    Console.WriteLine("=================================");
                                    Console.WriteLine($"Numer na Liście: {danie1.Id}");
                                    Console.WriteLine($"Nazwa: {danie1.Nazwa}");
                                    Console.WriteLine($"Cena: {danie1.Cena}");
                                    Console.WriteLine($"Opis: {danie1.OpisRybne}");
                                    Console.WriteLine("=================================");
                                }
                                Console.WriteLine(" ");
                                goto Usuwanie1;
                            }
                        }
                    }
                    Console.WriteLine(" ");
                    break;
                //////////////////////////////////////////////
                case "3":
                    Console.Clear();
                    foreach (Napoje danie3 in dania3)
                    {
                        Console.WriteLine(" ");
                        Console.WriteLine("=================================");
                        Console.WriteLine($"Numer na Liście: {danie3.Id}");
                        Console.WriteLine($"Nazwa: {danie3.Nazwa}");
                        Console.WriteLine($"Cena: {danie3.Cena}");
                        Console.WriteLine($"Opis: {danie3.OpisNapoje}");
                        Console.WriteLine("=================================");
                    }
                    Console.WriteLine(" ");
                    Console.WriteLine("1. Dodaj przedmiot");
                    Console.WriteLine("2. Usuń przedmiot");
                    Console.WriteLine("3. Powrót do menu");
                    string a8 = Console.ReadLine();
                    if (a8 == "3")
                    {
                        Console.Clear();
                        goto Menu;
                    }
                    else
                    {

                    }
                    if (a8 == "1")
                    {

                        Console.Clear();
                        Console.WriteLine(" ");
                        Console.WriteLine("========================== ");
                        Console.WriteLine("    DODAWANIE DO MENU ");
                        Console.WriteLine("========================== ");
                        Console.WriteLine(" ");
                        foreach (Napoje danie3 in dania3)
                        {
                            Console.WriteLine(" ");
                            Console.WriteLine("=================================");
                            Console.WriteLine($"Numer na Liście: {danie3.Id}");
                            Console.WriteLine($"Nazwa: {danie3.Nazwa}");
                            Console.WriteLine($"Cena: {danie3.Cena}");
                            Console.WriteLine($"Opis: {danie3.OpisNapoje}");
                            Console.WriteLine("=================================");
                        }
                        Console.WriteLine(" ");
                    Wroc9:
                        Console.WriteLine("1. Podaj kolejne wolne Id");
                        string b9 = Console.ReadLine();
                        int number9;
                        bool success9 = Int32.TryParse(b9, out number9);
                        if (success9)
                        {
                            Console.Clear();
                            bool bExist1 = dania3.Exists(Element1 => Element1.Id.Equals(number9));
                            if (bExist1)
                            {
                                Console.Clear();
                                Console.WriteLine("Podane Id już istnieje");
                                System.Threading.Thread.Sleep(2200);
                                Console.Clear();
                                Console.WriteLine(" ");
                                foreach (Napoje danie3 in dania3)
                                {
                                    Console.WriteLine(" ");
                                    Console.WriteLine("=================================");
                                    Console.WriteLine($"Numer na Liście: {danie3.Id}");
                                    Console.WriteLine($"Nazwa: {danie3.Nazwa}");
                                    Console.WriteLine($"Cena: {danie3.Cena}");
                                    Console.WriteLine($"Opis: {danie3.OpisNapoje}");
                                    Console.WriteLine("=================================");
                                }
                                Console.WriteLine(" ");
                                goto Wroc9;
                            }
                            else
                            {

                            }
                        }
                        else
                        {
                            Console.Clear();
                            Console.WriteLine("Proszę wpisać liczbę !");
                            System.Threading.Thread.Sleep(2200);
                            Console.Clear();
                            Console.WriteLine(" ");
                            foreach (Napoje danie3 in dania3)
                            {
                                Console.WriteLine(" ");
                                Console.WriteLine("=================================");
                                Console.WriteLine($"Numer na Liście: {danie3.Id}");
                                Console.WriteLine($"Nazwa: {danie3.Nazwa}");
                                Console.WriteLine($"Cena: {danie3.Cena}");
                                Console.WriteLine($"Opis: {danie3.OpisNapoje}");
                                Console.WriteLine("=================================");
                            }
                            Console.WriteLine(" ");
                            goto Wroc9;
                        }

                    Wroc10:
                        Console.WriteLine("2. Podaj Nazwe");
                        string c10 = Console.ReadLine();
                        int number10;
                        bool success10 = Int32.TryParse(c10, out number10);
                        if (success10)
                        {
                            Console.Clear();
                            Console.WriteLine("Proszę wpisać znaki nie liczby !");
                            System.Threading.Thread.Sleep(2200);
                            Console.Clear();
                            Console.WriteLine(" ");
                            foreach (Napoje danie3 in dania3)
                            {
                                Console.WriteLine(" ");
                                Console.WriteLine("=================================");
                                Console.WriteLine($"Numer na Liście: {danie3.Id}");
                                Console.WriteLine($"Nazwa: {danie3.Nazwa}");
                                Console.WriteLine($"Cena: {danie3.Cena}");
                                Console.WriteLine($"Opis: {danie3.OpisNapoje}");
                                Console.WriteLine("=================================");
                            }
                            Console.WriteLine(" ");
                            goto Wroc10;
                        }
                        else
                        {
                            Console.Clear();
                        }
                    Wroc11:
                        Console.WriteLine("3. Podaj cene bez przecinków i kropek");
                        string d11 = Console.ReadLine();
                        int number11;
                        bool success11 = Int32.TryParse(d11, out number11);
                        if (success11)
                        {
                            Console.Clear();
                        }
                        else
                        {
                            Console.Clear();
                            Console.WriteLine("Cena to liczba nie znaki !");
                            System.Threading.Thread.Sleep(2200);
                            Console.Clear();
                            Console.WriteLine(" ");
                            foreach (Napoje danie3 in dania3)
                            {
                                Console.WriteLine(" ");
                                Console.WriteLine("=================================");
                                Console.WriteLine($"Numer na Liście: {danie3.Id}");
                                Console.WriteLine($"Nazwa: {danie3.Nazwa}");
                                Console.WriteLine($"Cena: {danie3.Cena}");
                                Console.WriteLine($"Opis: {danie3.OpisNapoje}");
                                Console.WriteLine("=================================");
                            }
                            Console.WriteLine(" ");
                            goto Wroc11;
                        }

                    Wroc12:
                        Console.WriteLine("4. Krótki opis");
                        string e12 = Console.ReadLine();
                        int number12;
                        bool success12 = Int32.TryParse(e12, out number12);
                        if (success12)
                        {
                            Console.Clear();
                            Console.WriteLine("Opis sklada sie w tym wypadku tylko ze znakow !");
                            System.Threading.Thread.Sleep(2200);
                            Console.Clear();
                            Console.WriteLine(" ");
                            foreach (Napoje danie3 in dania3)
                            {
                                Console.WriteLine(" ");
                                Console.WriteLine("=================================");
                                Console.WriteLine($"Numer na Liście: {danie3.Id}");
                                Console.WriteLine($"Nazwa: {danie3.Nazwa}");
                                Console.WriteLine($"Cena: {danie3.Cena}");
                                Console.WriteLine($"Opis: {danie3.OpisNapoje}");
                                Console.WriteLine("=================================");
                            }
                            Console.WriteLine(" ");
                            goto Wroc12;
                        }
                        else
                        {
                            Console.Clear();
                        }
                        dania3.Add(new Napoje(number9, c10, number11, e12));
                        Console.WriteLine(" ");
                        Console.Clear();
                        foreach (Napoje danie3 in dania3)
                        {
                            Console.WriteLine(" ");
                            Console.WriteLine("=================================");
                            Console.WriteLine($"Numer na Liście: {danie3.Id}");
                            Console.WriteLine($"Nazwa: {danie3.Nazwa}");
                            Console.WriteLine($"Cena: {danie3.Cena}");
                            Console.WriteLine($"Opis: {danie3.OpisNapoje}");
                            Console.WriteLine("=================================");
                        }

                        using (StreamWriter sw3 = new StreamWriter("napoje.txt"))
                        {
                            foreach (Napoje danie3 in dania3)
                            {
                                sw3.WriteLine("{0},{1},{2},{3}", (danie3.Id), danie3.Nazwa, danie3.Cena, danie3.OpisNapoje);

                            }
                            sw3.Close();
                        }

                        Console.WriteLine(" ");
                        Console.WriteLine("Co chcesz zrobić? ");
                        Console.WriteLine(" ");
                        Console.WriteLine("1. Powrót do głównego MENU");
                        int powrot_napoje = int.Parse(Console.ReadLine());
                        if (powrot_napoje == 1)
                        {
                            Console.Clear();
                            goto Menu;
                        }
                        else
                        {
                        }
                    }
                    else
                    {
                        Console.Clear();
                        Console.WriteLine("==================");
                        Console.WriteLine("   USUWANIE");
                        Console.WriteLine("==================");
                        Console.WriteLine(" ");
                        Console.WriteLine(" ");
                        foreach (Napoje danie3 in dania3)
                        {
                            Console.WriteLine(" ");
                            Console.WriteLine("=================================");
                            Console.WriteLine($"Numer na Liście: {danie3.Id}");
                            Console.WriteLine($"Nazwa: {danie3.Nazwa}");
                            Console.WriteLine($"Cena: {danie3.Cena}");
                            Console.WriteLine($"Opis: {danie3.OpisNapoje}");
                            Console.WriteLine("=================================");
                        }
                        Console.WriteLine(" ");


                    Usuwanie3:

                        Console.WriteLine("Podaj numer ID");
                        Console.WriteLine("====================================================================");
                        Console.WriteLine("   Pamiętaj !!! Numery w liscie zaczynają sie od 0 ");
                        Console.WriteLine("   Jeśli coś ma ID np 3 to 3-1 = 2 czyli trzeba usunąć nr 2  :)");
                        Console.WriteLine("====================================================================");
                        Console.WriteLine(" ");
                        Console.WriteLine("====================================================================");
                        Console.WriteLine("   Jeśli chcesz cofnąć do menu wciśnij     k :)");
                        Console.WriteLine("====================================================================");
                        string usuwanie4 = Console.ReadLine();
                        int usuwanie5;
                        bool success22 = Int32.TryParse(usuwanie4, out usuwanie5);
                        if (success22)
                        {
                            Console.Clear();
                            dania.RemoveAt(usuwanie5);

                            using (StreamWriter sw10 = new StreamWriter("napoje.txt"))
                            {
                                foreach (Napoje danie3 in dania3)
                                {
                                    sw10.WriteLine("{0},{1},{2},{3}", (danie3.Id), danie3.Nazwa, danie3.Cena, danie3.OpisNapoje);

                                }
                                sw10.Close();
                            }
                            goto Menu;
                        }
                        else
                        {
                            if (usuwanie4 == "k")
                            {
                                Console.Clear();
                                goto Menu;
                            }
                            else
                            {


                                Console.Clear();
                                Console.WriteLine("Podaj liczbe nie znak !");
                                System.Threading.Thread.Sleep(2200);
                                Console.Clear();
                                Console.WriteLine(" ");
                                foreach (Napoje danie3 in dania3)
                                {
                                    Console.WriteLine(" ");
                                    Console.WriteLine("=================================");
                                    Console.WriteLine($"Numer na Liście: {danie3.Id}");
                                    Console.WriteLine($"Nazwa: {danie3.Nazwa}");
                                    Console.WriteLine($"Cena: {danie3.Cena}");
                                    Console.WriteLine($"Opis: {danie3.OpisNapoje}");
                                    Console.WriteLine("=================================");
                                }
                                Console.WriteLine(" ");
                                goto Usuwanie3;
                            }
                        }

                    }
                    Console.WriteLine(" ");
                    break;
                //////////////////////////////////////////////
                case "4":
                    Console.Clear();
                    foreach (Desery danie2 in dania2)
                    {
                        Console.WriteLine(" ");
                        Console.WriteLine("=================================");
                        Console.WriteLine($"Numer na Liście: {danie2.Id}");
                        Console.WriteLine($"Nazwa: {danie2.Nazwa}");
                        Console.WriteLine($"Cena: {danie2.Cena}");
                        Console.WriteLine($"Opis: {danie2.OpisDesery}");
                        Console.WriteLine("=================================");

                    }
                    Console.WriteLine(" ");
                    Console.WriteLine("1. Dodaj przedmiot");
                    Console.WriteLine("2. Usuń przedmiot");
                    Console.WriteLine("3. Powrót do menu");
                    string a12 = Console.ReadLine();
                    if (a12 == "3")
                    {
                        Console.Clear();
                        goto Menu;
                    }
                    else
                    {

                    }
                    if (a12 == "1")
                    {

                        Console.Clear();
                        Console.WriteLine(" ");
                        Console.WriteLine("========================== ");
                        Console.WriteLine("    DODAWANIE DO MENU ");
                        Console.WriteLine("========================== ");
                        Console.WriteLine(" ");
                        foreach (Desery danie2 in dania2)
                        {
                            Console.WriteLine(" ");
                            Console.WriteLine("=================================");
                            Console.WriteLine($"Numer na Liście: {danie2.Id}");
                            Console.WriteLine($"Nazwa: {danie2.Nazwa}");
                            Console.WriteLine($"Cena: {danie2.Cena}");
                            Console.WriteLine($"Opis: {danie2.OpisDesery}");
                            Console.WriteLine("=================================");
                        }
                        Console.WriteLine(" ");
                    Wroc13:
                        Console.WriteLine("1. Podaj kolejne wolne Id");
                        string b14 = Console.ReadLine();
                        int number14;
                        bool success14 = Int32.TryParse(b14, out number14);
                        if (success14)
                        {
                            Console.Clear();

                            bool bExist = dania2.Exists(Element => Element.Id.Equals(number14));
                            if (bExist)
                            {
                                Console.Clear();
                                Console.WriteLine("Podane Id już istnieje");
                                System.Threading.Thread.Sleep(2200);
                                Console.Clear();
                                Console.WriteLine(" ");
                                foreach (Desery danie2 in dania2)
                                {
                                    Console.WriteLine(" ");
                                    Console.WriteLine("=================================");
                                    Console.WriteLine($"Numer na Liście: {danie2.Id}");
                                    Console.WriteLine($"Nazwa: {danie2.Nazwa}");
                                    Console.WriteLine($"Cena: {danie2.Cena}");
                                    Console.WriteLine($"Opis: {danie2.OpisDesery}");
                                    Console.WriteLine("=================================");
                                }
                                Console.WriteLine(" ");
                                goto Wroc13;
                            }
                            else
                            {

                            }
                        }
                        else
                        {
                            Console.Clear();
                            Console.WriteLine("Proszę wpisać liczbę !");
                            System.Threading.Thread.Sleep(2200);
                            Console.Clear();
                            Console.WriteLine(" ");
                            foreach (Desery danie2 in dania2)
                            {
                                Console.WriteLine(" ");
                                Console.WriteLine("=================================");
                                Console.WriteLine($"Numer na Liście: {danie2.Id}");
                                Console.WriteLine($"Nazwa: {danie2.Nazwa}");
                                Console.WriteLine($"Cena: {danie2.Cena}");
                                Console.WriteLine($"Opis: {danie2.OpisDesery}");
                                Console.WriteLine("=================================");
                            }
                            Console.WriteLine(" ");
                            goto Wroc13;
                        }

                    Wroc14:
                        Console.WriteLine("2. Podaj Nazwe");
                        string c15 = Console.ReadLine();
                        int number15;
                        bool success15 = Int32.TryParse(c15, out number15);
                        if (success15)
                        {
                            Console.Clear();
                            Console.WriteLine("Proszę wpisać znaki nie liczby !");
                            System.Threading.Thread.Sleep(2200);
                            Console.Clear();
                            Console.WriteLine(" ");
                            foreach (Desery danie2 in dania2)
                            {
                                Console.WriteLine(" ");
                                Console.WriteLine("=================================");
                                Console.WriteLine($"Numer na Liście: {danie2.Id}");
                                Console.WriteLine($"Nazwa: {danie2.Nazwa}");
                                Console.WriteLine($"Cena: {danie2.Cena}");
                                Console.WriteLine($"Opis: {danie2.OpisDesery}");
                                Console.WriteLine("=================================");
                            }
                            Console.WriteLine(" ");
                            goto Wroc14;
                        }
                        else
                        {
                            Console.Clear();
                        }
                    Wroc15:
                        Console.WriteLine("3. Podaj cene bez przecinków i kropek");
                        string d16 = Console.ReadLine();
                        int number16;
                        bool success16 = Int32.TryParse(d16, out number16);
                        if (success16)
                        {
                            Console.Clear();
                        }
                        else
                        {
                            Console.Clear();
                            Console.WriteLine("Cena to liczba nie znaki !");
                            System.Threading.Thread.Sleep(2200);
                            Console.Clear();
                            Console.WriteLine(" ");
                            foreach (Desery danie2 in dania2)
                            {
                                Console.WriteLine(" ");
                                Console.WriteLine("=================================");
                                Console.WriteLine($"Numer na Liście: {danie2.Id}");
                                Console.WriteLine($"Nazwa: {danie2.Nazwa}");
                                Console.WriteLine($"Cena: {danie2.Cena}");
                                Console.WriteLine($"Opis: {danie2.OpisDesery}");
                                Console.WriteLine("=================================");
                            }
                            Console.WriteLine(" ");
                            goto Wroc15;
                        }

                    Wroc16:
                        Console.WriteLine("4. Krótki opis");
                        string e17 = Console.ReadLine();
                        int number17;
                        bool success17 = Int32.TryParse(e17, out number17);
                        if (success17)
                        {
                            Console.Clear();
                            Console.WriteLine("Opis sklada sie w tym wypadku tylko ze znakow !");
                            System.Threading.Thread.Sleep(2200);
                            Console.Clear();
                            Console.WriteLine(" ");
                            foreach (Desery danie2 in dania2)
                            {
                                Console.WriteLine(" ");
                                Console.WriteLine("=================================");
                                Console.WriteLine($"Numer na Liście: {danie2.Id}");
                                Console.WriteLine($"Nazwa: {danie2.Nazwa}");
                                Console.WriteLine($"Cena: {danie2.Cena}");
                                Console.WriteLine($"Opis: {danie2.OpisDesery}");
                                Console.WriteLine("=================================");
                            }
                            Console.WriteLine(" ");
                            goto Wroc16;
                        }
                        else
                        {
                            Console.Clear();
                        }
                        dania2.Add(new Desery(number14, c15, number16, e17));
                        Console.WriteLine(" ");
                        Console.Clear();
                        foreach (Desery danie2 in dania2)
                        {
                            Console.WriteLine(" ");
                            Console.WriteLine("=================================");
                            Console.WriteLine($"Numer na Liście: {danie2.Id}");
                            Console.WriteLine($"Nazwa: {danie2.Nazwa}");
                            Console.WriteLine($"Cena: {danie2.Cena}");
                            Console.WriteLine($"Opis: {danie2.OpisDesery}");
                            Console.WriteLine("=================================");
                        }

                        using (StreamWriter sw4 = new StreamWriter("desery.txt"))
                        {
                            foreach (Desery danie2 in dania2)
                            {
                                sw4.WriteLine("{0},{1},{2},{3}", (danie2.Id), danie2.Nazwa, danie2.Cena, danie2.OpisDesery);

                            }
                            sw4.Close();
                        }

                        Console.WriteLine(" ");
                        Console.WriteLine("Co chcesz zrobić? ");
                        Console.WriteLine(" ");
                        Console.WriteLine("1. Powrót do głównego MENU");
                        int powrot_desery = int.Parse(Console.ReadLine());
                        if (powrot_desery == 1)
                        {
                            Console.Clear();
                            goto Menu;
                        }
                        else
                        {
                        }
                    }
                    else
                    {
                        Console.Clear();
                        Console.WriteLine("==================");
                        Console.WriteLine("   USUWANIE");
                        Console.WriteLine("==================");
                        Console.WriteLine(" ");
                        Console.WriteLine(" ");
                        foreach (Desery danie2 in dania2)
                        {
                            Console.WriteLine(" ");
                            Console.WriteLine("=================================");
                            Console.WriteLine($"Numer na Liście: {danie2.Id}");
                            Console.WriteLine($"Nazwa: {danie2.Nazwa}");
                            Console.WriteLine($"Cena: {danie2.Cena}");
                            Console.WriteLine($"Opis: {danie2.OpisDesery}");
                            Console.WriteLine("=================================");
                        }
                        Console.WriteLine(" ");


                    Usuwanie4:
                        Console.WriteLine("Podaj numer ID");
                        Console.WriteLine("====================================================================");
                        Console.WriteLine("   Pamiętaj !!! Numery w liscie zaczynają sie od 0 ");
                        Console.WriteLine("   Jeśli coś ma ID np 3 to 3-1 = 2 czyli trzeba usunąć nr 2  :)");
                        Console.WriteLine("====================================================================");
                        Console.WriteLine(" ");
                        Console.WriteLine("====================================================================");
                        Console.WriteLine("   Jeśli chcesz cofnąć do menu wciśnij     k :)");
                        Console.WriteLine("====================================================================");
                        string usuwanie6 = Console.ReadLine();
                        int usuwanie7;
                        bool success23 = Int32.TryParse(usuwanie6, out usuwanie7);
                        if (success23)
                        {
                            Console.Clear();
                            dania.RemoveAt(usuwanie7);
                            using (StreamWriter sw11 = new StreamWriter("desery.txt"))
                            {
                                foreach (Desery danie2 in dania2)
                                {
                                    sw11.WriteLine("{0},{1},{2},{3}", (danie2.Id), danie2.Nazwa, danie2.Cena, danie2.OpisDesery);

                                }
                                sw11.Close();
                            }
                            goto Menu;
                        }
                        else
                        {
                            if (usuwanie6 == "k")
                            {
                                Console.Clear();
                                goto Menu;
                            }
                            else
                            {
                                Console.Clear();
                                Console.WriteLine("Podaj liczbe nie znak !");
                                System.Threading.Thread.Sleep(2200);
                                Console.Clear();
                                Console.WriteLine(" ");
                                foreach (Desery danie2 in dania2)
                                {
                                    Console.WriteLine(" ");
                                    Console.WriteLine("=================================");
                                    Console.WriteLine($"Numer na Liście: {danie2.Id}");
                                    Console.WriteLine($"Nazwa: {danie2.Nazwa}");
                                    Console.WriteLine($"Cena: {danie2.Cena}");
                                    Console.WriteLine($"Opis: {danie2.OpisDesery}");
                                    Console.WriteLine("=================================");
                                }
                                Console.WriteLine(" ");
                                goto Usuwanie4;
                            }
                        }
                    }
                    Console.WriteLine(" ");
                    break;
                //////////////////////////////////////////////
                case "5":
                    Console.Clear();
                    foreach (Zupy danie6 in dania6)
                    {
                        Console.WriteLine(" ");
                        Console.WriteLine("=================================");
                        Console.WriteLine($"Numer na Liście: {danie6.Id}");
                        Console.WriteLine($"Nazwa: {danie6.Nazwa}");
                        Console.WriteLine($"Cena: {danie6.Cena}");
                        Console.WriteLine($"Opis: {danie6.OpisZupy}");
                        Console.WriteLine("=================================");
                    }
                    Console.WriteLine(" ");
                    Console.WriteLine(" ");
                    Console.WriteLine(" ");
                    Console.WriteLine(" ");
                    Console.WriteLine("================================================= ");
                    Console.WriteLine("Ta kategoria pozostaje bez możliwości edycji");
                    Console.WriteLine("================================================= ");
                    Console.WriteLine(" ");
                PowrotZupy:
                    Console.WriteLine(" ");
                    Console.WriteLine("Co chcesz zrobić? ");
                    Console.WriteLine(" ");
                    Console.WriteLine("1. Powrót do głównego MENU");
                    string powrot_zupy = Console.ReadLine();
                    int powrot_zupy1;
                    bool success26 = Int32.TryParse(powrot_zupy, out powrot_zupy1);
                    if (success26)
                    {
                        if (powrot_zupy1 == 1)
                        {


                            Console.Clear();
                            goto Menu;
                        }
                        else
                        {
                            Console.WriteLine("Tylko jedna opcja jest do wyboru = 1");
                            System.Threading.Thread.Sleep(2200);
                            Console.Clear();
                            goto PowrotZupy;
                        }
                    }
                    else
                    {
                        Console.WriteLine("Podałeś nieprawidłowy znak");
                        System.Threading.Thread.Sleep(2200);
                        Console.Clear();
                        goto PowrotZupy;

                    }
                //////////////////////////////////////////////
                case "6":
                    Console.Clear();
                    foreach (Pierogi danie4 in dania4)
                    {
                        Console.WriteLine(" ");
                        Console.WriteLine("=================================");
                        Console.WriteLine($"Numer na Liście: {danie4.Id}");
                        Console.WriteLine($"Nazwa: {danie4.Nazwa}");
                        Console.WriteLine($"Cena: {danie4.Cena}");
                        Console.WriteLine($"Opis: {danie4.OpisPierogi}");
                        Console.WriteLine("=================================");
                    }
                    Console.WriteLine(" ");
                    Console.WriteLine("================================================= ");
                    Console.WriteLine("Ta kategoria pozostaje bez możliwości edycji");
                    Console.WriteLine("================================================= ");
                    Console.WriteLine(" ");
                PowrotPierogi:
                    Console.WriteLine(" ");
                    Console.WriteLine("Co chcesz zrobić? ");
                    Console.WriteLine(" ");
                    Console.WriteLine("1. Powrót do głównego MENU");
                    string powrot_pierogi = Console.ReadLine();
                    int powrot_pierogi1;
                    bool success27 = Int32.TryParse(powrot_pierogi, out powrot_pierogi1);
                    if (success27)
                    {
                        if (powrot_pierogi1 == 1)
                        {


                            Console.Clear();
                            goto Menu;
                        }
                        else
                        {
                            Console.WriteLine("Tylko jedna opcja jest do wyboru = 1");
                            System.Threading.Thread.Sleep(2200);
                            Console.Clear();
                            goto PowrotPierogi;
                        }
                    }
                    else
                    {
                        Console.WriteLine("Podałeś nieprawidłowy znak");
                        System.Threading.Thread.Sleep(2200);
                        Console.Clear();
                        goto PowrotPierogi;

                    }
                //////////////////////////////////////////////
                case "7":
                    Console.Clear();
                    foreach (Salaty danie5 in dania5)
                    {
                        Console.WriteLine(" ");
                        Console.WriteLine("=================================");
                        Console.WriteLine($"Numer na Liście: {danie5.Id}");
                        Console.WriteLine($"Nazwa: {danie5.Nazwa}");
                        Console.WriteLine($"Cena: {danie5.Cena}");
                        Console.WriteLine($"Opis: {danie5.OpisSalaty}");
                        Console.WriteLine("=================================");
                    }

                    Console.WriteLine(" ");
                    Console.WriteLine("================================================= ");
                    Console.WriteLine("Ta kategoria pozostaje bez możliwości edycji");
                    Console.WriteLine("================================================= ");
                    Console.WriteLine(" ");
                PowrotSalaty:
                    Console.WriteLine(" ");
                    Console.WriteLine("Co chcesz zrobić? ");
                    Console.WriteLine(" ");
                    Console.WriteLine("1. Powrót do głównego MENU");

                    string powrot_salaty = Console.ReadLine();
                    int powrot_salaty1;
                    bool success28 = Int32.TryParse(powrot_salaty, out powrot_salaty1);
                    if (success28)
                    {
                        if (powrot_salaty1 == 1)
                        {


                            Console.Clear();
                            goto Menu;
                        }
                        else
                        {
                            Console.WriteLine("Tylko jedna opcja jest do wyboru = 1");
                            System.Threading.Thread.Sleep(2200);
                            Console.Clear();
                            goto PowrotSalaty;
                        }
                    }
                    else
                    {
                        Console.WriteLine("Podałeś nieprawidłowy znak");
                        System.Threading.Thread.Sleep(2200);
                        Console.Clear();
                        goto PowrotSalaty;

                    }
                //////////////////////////////////////////////
                case "8":
                    Console.Clear();
                    break;
                default:
                    Console.Clear();
                    Console.WriteLine("Podaj cyfre od 1 do 8");
                    System.Threading.Thread.Sleep(2200);
                    Console.Clear();
                    goto Menu;


            }
        }
    }
}
