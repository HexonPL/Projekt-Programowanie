﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;

namespace ConsoleApp4
{
    class Rejestracja
    {
        public string Login { get; set; }
        public string Haslo { get; set; }
        public string Ranga = "Ogladajacy";

        public Rejestracja(string login, string haslo, string ranga)
        {
            this.Login = login;
            this.Haslo = haslo;
            this.Ranga = ranga;
        }

        public static void Reje()
        {
            List<Rejestracja> rejestracje = new List<Rejestracja>();
        Login:
            Console.Clear();
            Console.WriteLine("1. Podaj Login");
            string Login = Console.ReadLine();
            int number_reje;
            bool success_reje = Int32.TryParse(Login, out number_reje);
            if (success_reje)
            {
                Console.Clear();
                Console.WriteLine("Proszę wpisać znaki nie liczby !");
                System.Threading.Thread.Sleep(2200);
                Console.Clear();
                goto Login;
            }
            else
            {
            Haslo:
                Console.Clear();
                Console.WriteLine("2. Podaj Haslo");
                string Haslo = Console.ReadLine();
                int number_reje2;
                bool success_reje2 = Int32.TryParse(Haslo, out number_reje2);
                if (success_reje2)
                {
                    Console.Clear();
                    Console.WriteLine("Proszę wpisać znaki nie liczby !");
                    System.Threading.Thread.Sleep(2200);
                    Console.Clear();
                    goto Haslo;
                }
                else
                {
                    rejestracje.Add(new Rejestracja(Login,Haslo,"Ogladajacy"));

                    using (StreamWriter rejes = new StreamWriter("dane_uzytkownikow.txt"))
                    {
                        foreach (Rejestracja rejestracja in rejestracje)
                        {
                            rejes.WriteLine("{0},{1},{2}", rejestracja.Login, rejestracja.Haslo,"Ogladajacy");

                        }
                        rejes.Close();
                        Console.Clear();
                        Console.WriteLine("Zarejestrowano, prosze o zalogowanie się");
                        System.Threading.Thread.Sleep(2200);
                        Console.Clear();
                        Logowanie.Login();
                    }

                }
            }
        }
    }
}
