﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    class Pierogi : Produkt
    {
        public string OpisPierogi { get; set; }

        public Pierogi(int Id, string Nazwa, int Cena, string OpisPierogi) : base(Id, Nazwa, Cena)
        {
            this.OpisPierogi = OpisPierogi;
        }

        public override void Przedstawienie()
        {
            base.Przedstawienie();
            Console.WriteLine("Kosztując nasze pierogi zapamiętasz je na zawsze");
        }
    }
}
