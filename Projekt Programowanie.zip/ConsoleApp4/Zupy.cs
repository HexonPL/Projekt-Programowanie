﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    class Zupy : Produkt
    {
        public string OpisZupy { get; set; }

        public Zupy(int Id, string Nazwa, int Cena, string OpisZupy) : base(Id, Nazwa, Cena)
        {
            this.OpisZupy = OpisZupy;
        }

        public override void Przedstawienie()
        {
            base.Przedstawienie();
            Console.WriteLine("Każdą naszą zupę wykonujemy sami, na miejscu");
        }
    }
}
