﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;


namespace ConsoleApp4
{
    class DaniaRybne : Produkt
    {
        public string OpisRybne { get; set; }

        public DaniaRybne(int Id, string Nazwa, int Cena, string OpisRybne) : base(Id, Nazwa, Cena)
        {
            this.OpisRybne = OpisRybne;
        }

        public override void Przedstawienie()
        {
            base.Przedstawienie();
            Console.WriteLine("Ryby dostarczane są od naszego zaufanego dostawcy");
        }
    }
}
