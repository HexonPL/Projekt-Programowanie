﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;

namespace ConsoleApp4
{
    class Program
    {
        static void Main(string[] args)
        {
            //////////////////////////////////////////////
            string fileName = "dania_miesne.txt";
            List<DaniaMiesne> dania = new List<DaniaMiesne>();
            String line;
            StreamReader sr = new StreamReader(fileName);
            while ((line = sr.ReadLine()) != null)
            {
                string[] s = line.Split(',');
                var danie = new DaniaMiesne
                {
                    id = int.Parse(s[0]),
                    nazwa = s[1],
                    cena = float.Parse(s[2]),
                    opis = s[3],

                };
                dania.Add(danie);
            }
            sr.Close();
            Console.ReadKey();
            ////////////////////////////////////////////////

        }
    }
}
