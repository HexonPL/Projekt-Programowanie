﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;

namespace ConsoleApp4
{
    class MenuUzytkownik
    {
        public static void PokazMenuUzytkownik()
        {
            //////////////////////////////////////////////
            string fileName = "dania_miesne.txt";
            List<DaniaMiesne> dania = new List<DaniaMiesne>();
            String line;
            StreamReader sr = new StreamReader(fileName);
            while ((line = sr.ReadLine()) != null)
            {
                string[] s = line.Split(',');

                int f = int.Parse(s[0]);
                string g = s[1];
                int h = int.Parse(s[2]);
                string i = s[3];
                dania.Add(new DaniaMiesne(f, g, h, i));
            }
            sr.Close();
            ////////////////////////////////////////////////
            string fileName1 = "dania_rybne.txt";
            List<DaniaRybne> dania1 = new List<DaniaRybne>();
            String line1;
            StreamReader sr1 = new StreamReader(fileName1);
            while ((line1 = sr1.ReadLine()) != null)
            {
                string[] s1 = line1.Split(',');
                int f1 = int.Parse(s1[0]);
                string g1 = s1[1];
                int h1 = int.Parse(s1[2]);
                string i1 = s1[3];
                dania1.Add(new DaniaRybne(f1, g1, h1, i1));
            }
            sr1.Close();
            ////////////////////////////////////////////////
            string fileName2 = "desery.txt";
            List<Desery> dania2 = new List<Desery>();
            String line2;
            StreamReader sr2 = new StreamReader(fileName2);
            while ((line2 = sr2.ReadLine()) != null)
            {
                string[] s2 = line2.Split(',');
                int f2 = int.Parse(s2[0]);
                string g2 = s2[1];
                int h2 = int.Parse(s2[2]);
                string i2 = s2[3];
                dania2.Add(new Desery(f2, g2, h2, i2));
            }
            sr2.Close();
            ////////////////////////////////////////////////
            string fileName3 = "napoje.txt";
            List<Napoje> dania3 = new List<Napoje>();
            String line3;
            StreamReader sr3 = new StreamReader(fileName3);
            while ((line3 = sr3.ReadLine()) != null)
            {
                string[] s3 = line3.Split(',');
                int f3 = int.Parse(s3[0]);
                string g3 = s3[1];
                int h3 = int.Parse(s3[2]);
                string i3 = s3[3];
                dania3.Add(new Napoje(f3, g3, h3, i3));
            }
            sr3.Close();
            ////////////////////////////////////////////////
            string fileName4 = "pierogi.txt";
            List<Pierogi> dania4 = new List<Pierogi>();
            String line4;
            StreamReader sr4 = new StreamReader(fileName4);
            while ((line4 = sr4.ReadLine()) != null)
            {
                string[] s4 = line4.Split(',');
                int f4 = int.Parse(s4[0]);
                string g4 = s4[1];
                int h4 = int.Parse(s4[2]);
                string i4 = s4[3];
                dania4.Add(new Pierogi(f4, g4, h4, i4));
            }
            sr4.Close();
            ////////////////////////////////////////////////
            string fileName5 = "salaty.txt";
            List<Salaty> dania5 = new List<Salaty>();
            String line5;
            StreamReader sr5 = new StreamReader(fileName5);
            while ((line5 = sr5.ReadLine()) != null)
            {
                string[] s5 = line5.Split(',');
                int f5 = int.Parse(s5[0]);
                string g5 = s5[1];
                int h5 = int.Parse(s5[2]);
                string i5 = s5[3];
                dania5.Add(new Salaty(f5, g5, h5, i5));
            }
            sr5.Close();
            ////////////////////////////////////////////////
            string fileName6 = "zupy.txt";
            List<Zupy> dania6 = new List<Zupy>();
            String line6;
            StreamReader sr6 = new StreamReader(fileName6);
            while ((line6 = sr6.ReadLine()) != null)
            {
                string[] s6 = line6.Split(',');
                int f6 = int.Parse(s6[0]);
                string g6 = s6[1];
                int h6 = int.Parse(s6[2]);
                string i6 = s6[3];
                dania6.Add(new Zupy(f6, g6, h6, i6));
            }
            sr6.Close();
            ////////////////////////////////////////////////




            Console.WriteLine("===============================================");
            Console.WriteLine("   Aplikacja zarządzająca menu restauracji");
            Console.WriteLine("===============================================");
            Console.WriteLine(" ");
            System.Threading.Thread.Sleep(2500);
            Console.WriteLine("=====================================================");
            Console.WriteLine(" Autorzy : Krzysztof Szałamacha , Oskar Suliński  K29");
            Console.WriteLine("=====================================================");
            Console.WriteLine(" ");
            System.Threading.Thread.Sleep(3600);
            Console.Clear();
        Menu:
            Console.WriteLine("===========================");
            Console.WriteLine("    Wybierz Numer z Listy :");
            Console.WriteLine("===========================");
            Console.WriteLine(" ");
            Console.WriteLine("1. Dania Miesne ");
            Console.WriteLine("2. Dania Rybne ");
            Console.WriteLine("3. Napoje ");
            Console.WriteLine("4. Desery ");
            Console.WriteLine("5. Zupy ");
            Console.WriteLine("6. Pierogi ");
            Console.WriteLine("7. Sałaty ");
            Console.WriteLine("==================");
            Console.WriteLine("8. Zamknij program ");
            Console.WriteLine("==================");
            switch (Console.ReadLine())
            {
                case "1":
                    Console.Clear();
                    foreach (DaniaMiesne danie in dania)
                    {
                        Console.WriteLine(" ");
                        Console.WriteLine("=================================");
                        Console.WriteLine($"Numer na Liście: {danie.Id}");
                        Console.WriteLine($"Nazwa: {danie.Nazwa}");
                        Console.WriteLine($"Cena: {danie.Cena}");
                        Console.WriteLine($"Opis: {danie.OpisMiesne}");
                        Console.WriteLine("=================================");
                    }
                    
                        Console.WriteLine(" ");
                        Console.WriteLine("Co chcesz zrobić? ");
                        Console.WriteLine(" ");
                        Console.WriteLine("1. Powrót do głównego MENU");
                        int powrot_daniamiesne = int.Parse(Console.ReadLine());
                        if (powrot_daniamiesne == 1)
                        {
                            Console.Clear();
                            goto Menu;
                        }
                        else
                        {
                        }
                    break;
                //////////////////////////////////////////////
                case "2":
                    Console.Clear();
                    foreach (DaniaRybne danie1 in dania1)
                    {
                        Console.WriteLine(" ");
                        Console.WriteLine("=================================");
                        Console.WriteLine($"Numer na Liście: {danie1.Id}");
                        Console.WriteLine($"Nazwa: {danie1.Nazwa}");
                        Console.WriteLine($"Cena: {danie1.Cena}");
                        Console.WriteLine($"Opis: {danie1.OpisRybne}");
                        Console.WriteLine("=================================");
                    }

                    Console.WriteLine(" ");
                    Console.WriteLine("Co chcesz zrobić? ");
                    Console.WriteLine(" ");
                    Console.WriteLine("1. Powrót do głównego MENU");
                    int powrot_daniarybne = int.Parse(Console.ReadLine());
                    if (powrot_daniarybne == 1)
                    {
                        Console.Clear();
                        goto Menu;
                    }
                    else
                    {
                    }

                    break;
                //////////////////////////////////////////////
                case "3":
                    Console.Clear();
                    foreach (Napoje danie3 in dania3)
                    {
                        Console.WriteLine(" ");
                        Console.WriteLine("=================================");
                        Console.WriteLine($"Numer na Liście: {danie3.Id}");
                        Console.WriteLine($"Nazwa: {danie3.Nazwa}");
                        Console.WriteLine($"Cena: {danie3.Cena}");
                        Console.WriteLine($"Opis: {danie3.OpisNapoje}");
                        Console.WriteLine("=================================");
                    }

                    Console.WriteLine(" ");
                    Console.WriteLine("Co chcesz zrobić? ");
                    Console.WriteLine(" ");
                    Console.WriteLine("1. Powrót do głównego MENU");
                    int powrot_napoje = int.Parse(Console.ReadLine());
                    if (powrot_napoje == 1)
                    {
                        Console.Clear();
                        goto Menu;
                    }
                    else
                    {
                    }
                    break;
                //////////////////////////////////////////////
                case "4":
                    Console.Clear();
                    foreach (Desery danie2 in dania2)
                    {
                        Console.WriteLine(" ");
                        Console.WriteLine("=================================");
                        Console.WriteLine($"Numer na Liście: {danie2.Id}");
                        Console.WriteLine($"Nazwa: {danie2.Nazwa}");
                        Console.WriteLine($"Cena: {danie2.Cena}");
                        Console.WriteLine($"Opis: {danie2.OpisDesery}");
                        Console.WriteLine("=================================");

                    }

                        Console.WriteLine(" ");
                        Console.WriteLine("Co chcesz zrobić? ");
                        Console.WriteLine(" ");
                        Console.WriteLine("1. Powrót do głównego MENU");
                        int powrot_desery = int.Parse(Console.ReadLine());
                        if (powrot_desery == 1)
                        {
                            Console.Clear();
                            goto Menu;
                        }
                        else
                        {
                        }
                    break;
                //////////////////////////////////////////////
                case "5":
                    Console.Clear();
                    foreach (Zupy danie6 in dania6)
                    {
                        Console.WriteLine(" ");
                        Console.WriteLine("=================================");
                        Console.WriteLine($"Numer na Liście: {danie6.Id}");
                        Console.WriteLine($"Nazwa: {danie6.Nazwa}");
                        Console.WriteLine($"Cena: {danie6.Cena}");
                        Console.WriteLine($"Opis: {danie6.OpisZupy}");
                        Console.WriteLine("=================================");
                    }
                PowrotZupy:
                    Console.WriteLine(" ");
                    Console.WriteLine("Co chcesz zrobić? ");
                    Console.WriteLine(" ");
                    Console.WriteLine("1. Powrót do głównego MENU");
                    string powrot_zupy = Console.ReadLine();
                    int powrot_zupy1;
                    bool success26 = Int32.TryParse(powrot_zupy, out powrot_zupy1);
                    if (success26)
                    {
                        if (powrot_zupy1 == 1)
                        {


                            Console.Clear();
                            goto Menu;
                        }
                        else
                        {
                            Console.WriteLine("Tylko jedna opcja jest do wyboru = 1");
                            System.Threading.Thread.Sleep(2200);
                            Console.Clear();
                            goto PowrotZupy;
                        }
                    }
                    else
                    {
                        Console.WriteLine("Podałeś nieprawidłowy znak");
                        System.Threading.Thread.Sleep(2200);
                        Console.Clear();
                        goto PowrotZupy;

                    }
                //////////////////////////////////////////////
                case "6":
                    Console.Clear();
                    foreach (Pierogi danie4 in dania4)
                    {
                        Console.WriteLine(" ");
                        Console.WriteLine("=================================");
                        Console.WriteLine($"Numer na Liście: {danie4.Id}");
                        Console.WriteLine($"Nazwa: {danie4.Nazwa}");
                        Console.WriteLine($"Cena: {danie4.Cena}");
                        Console.WriteLine($"Opis: {danie4.OpisPierogi}");
                        Console.WriteLine("=================================");
                    }
                PowrotPierogi:
                    Console.WriteLine(" ");
                    Console.WriteLine("Co chcesz zrobić? ");
                    Console.WriteLine(" ");
                    Console.WriteLine("1. Powrót do głównego MENU");
                    string powrot_pierogi = Console.ReadLine();
                    int powrot_pierogi1;
                    bool success27 = Int32.TryParse(powrot_pierogi, out powrot_pierogi1);
                    if (success27)
                    {
                        if (powrot_pierogi1 == 1)
                        {


                            Console.Clear();
                            goto Menu;
                        }
                        else
                        {
                            Console.WriteLine("Tylko jedna opcja jest do wyboru = 1");
                            System.Threading.Thread.Sleep(2200);
                            Console.Clear();
                            goto PowrotPierogi;
                        }
                    }
                    else
                    {
                        Console.WriteLine("Podałeś nieprawidłowy znak");
                        System.Threading.Thread.Sleep(2200);
                        Console.Clear();
                        goto PowrotPierogi;

                    }
                //////////////////////////////////////////////
                case "7":
                    Console.Clear();
                    foreach (Salaty danie5 in dania5)
                    {
                        Console.WriteLine(" ");
                        Console.WriteLine("=================================");
                        Console.WriteLine($"Numer na Liście: {danie5.Id}");
                        Console.WriteLine($"Nazwa: {danie5.Nazwa}");
                        Console.WriteLine($"Cena: {danie5.Cena}");
                        Console.WriteLine($"Opis: {danie5.OpisSalaty}");
                        Console.WriteLine("=================================");
                    }
                PowrotSalaty:
                    Console.WriteLine(" ");
                    Console.WriteLine("Co chcesz zrobić? ");
                    Console.WriteLine(" ");
                    Console.WriteLine("1. Powrót do głównego MENU");

                    string powrot_salaty = Console.ReadLine();
                    int powrot_salaty1;
                    bool success28 = Int32.TryParse(powrot_salaty, out powrot_salaty1);
                    if (success28)
                    {
                        if (powrot_salaty1 == 1)
                        {


                            Console.Clear();
                            goto Menu;
                        }
                        else
                        {
                            Console.WriteLine("Tylko jedna opcja jest do wyboru = 1");
                            System.Threading.Thread.Sleep(2200);
                            Console.Clear();
                            goto PowrotSalaty;
                        }
                    }
                    else
                    {
                        Console.WriteLine("Podałeś nieprawidłowy znak");
                        System.Threading.Thread.Sleep(2200);
                        Console.Clear();
                        goto PowrotSalaty;

                    }
                //////////////////////////////////////////////
                case "8":
                    Console.Clear();
                    break;
                default:
                    Console.Clear();
                    Console.WriteLine("Podaj cyfre od 1 do 8");
                    System.Threading.Thread.Sleep(2200);
                    Console.Clear();
                    goto Menu;


            }
        }
    }
}
