﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    class Salaty : Produkt
    {
        public string OpisSalaty { get; set; }

        public Salaty(int Id, string Nazwa, int Cena, string OpisSalaty) : base(Id, Nazwa, Cena)
        {
            this.OpisSalaty = OpisSalaty;
        }

        public override void Przedstawienie()
        {
            base.Przedstawienie();
            Console.WriteLine("Każda sałata sprowadzamy od naszych lokalnych Dostawców");
        }
    }
}
