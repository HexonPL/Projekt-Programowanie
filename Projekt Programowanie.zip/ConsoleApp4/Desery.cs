﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    class Desery : Produkt
    {
        public string OpisDesery { get; set; }

        public Desery(int Id, string Nazwa, int Cena, string OpisDesery) : base(Id, Nazwa, Cena)
        {
            this.OpisDesery = OpisDesery;
        }

        public override void Przedstawienie()
        {
            base.Przedstawienie();
            Console.WriteLine("Puszysta Bita Śmietana to jest to co każdy uwielbia w Lodach");
        }
    }
}
