﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;

namespace ConsoleApp4
{
    class Logowanie
    {
        public string Login2 { get; set; }
        public string Haslo2 { get; set; }

        public Logowanie(string login2, string haslo2)
        {
            this.Login2 = login2;
            this.Haslo2 = haslo2;
        }

        public static void Login()
        {
            //////////////////////////////////////////////
            string fileName = "dane_uzytkownikow.txt";
            List<Logowanie> logowania = new List<Logowanie>();
            String line;
            StreamReader sr2 = new StreamReader(fileName);
            while ((line = sr2.ReadLine()) != null)
            {
                string[] s = line.Split(',');
                string g = s[0];
                string i = s[1];
                logowania.Add(new Logowanie(g, i));
            }
            sr2.Close();
        ////////////////////////////////////////////////
        Login:
            Console.Clear();
            Console.WriteLine("1. Wpisz Login");
            string b = Console.ReadLine();
            int number;
            bool success = Int32.TryParse(b, out number);
            if (success)
            {
                Console.Clear();
                Console.WriteLine("Prosze o wpisywanie liter");
                goto Login;
            }
            else
            {
                bool bExist3 = logowania.Exists(Element1 => Element1.Login2.Equals(b));
                if (bExist3 == true)
                {
                Haslo:
                    Console.Clear();
                    Console.WriteLine("2. Wpisz Hasło");
                    string b2 = Console.ReadLine();
                    int number2;
                    bool success2 = Int32.TryParse(b2, out number2);
                    if (success2)
                    {
                        Console.Clear();
                        Console.WriteLine("Prosze o wpisywanie liter");
                        goto Haslo;
                    }
                    else
                    {
                        bool bExist33 = logowania.Exists(Element1 => Element1.Haslo2.Equals(b2));

                        if (bExist33 == true)
                        {
                            Console.Clear();
                            Console.WriteLine("Zalogowano Pomyślnie");
                            System.Threading.Thread.Sleep(2200);
                            Console.Clear();
                            MenuUzytkownik.PokazMenuUzytkownik();
                        }
                        else
                        {
                            Console.Clear();
                            Console.WriteLine("Taki uzytkownik nie istnieje");
                            System.Threading.Thread.Sleep(2200);
                            Console.Clear();
                            goto Haslo;
                        }
                    }

                }
                else
                {
                    Console.Clear();
                    Console.WriteLine("Taki uzytkownik nie istnieje");
                    System.Threading.Thread.Sleep(2200);
                    Console.Clear();
                    goto Login;
                }
            }

        }
    }
}